# Alternative sidebars

Your project can have as many sidebars as you want.
You may only need one.

